package com.example.jetty

import org.eclipse.jetty.server._
import org.eclipse.jetty.util.ssl.SslContextFactory
import org.eclipse.jetty.http2.server.HTTP2ServerConnectionFactory
import org.eclipse.jetty.alpn.server.ALPNServerConnectionFactory
import org.eclipse.jetty.util.Callback

import java.net.http.{HttpClient, HttpRequest, HttpResponse}
import java.net.URI
import javax.net.ssl.{KeyManagerFactory, SSLContext, TrustManagerFactory}
import java.security.KeyStore
import java.io.FileInputStream

object MinimalReproduction {

  def main(args: Array[String]): Unit = {
    val server = new Server()

    val ssl = new SslContextFactory.Server()
    ssl.setKeyStorePath("tls/keystore.jks")
    ssl.setKeyStorePassword("changeit")
    ssl.setTrustStorePath("tls/truststore.jks")
    ssl.setTrustStorePassword("changeit")

    val http2 = new HTTP2ServerConnectionFactory()
    val alpn = new ALPNServerConnectionFactory()
    alpn.setDefaultProtocol("http/1.1")

    val connector = new ServerConnector(server,
      new SslConnectionFactory(ssl, alpn.getProtocol),
      alpn, http2, new HttpConnectionFactory())
    connector.setPort(8443)
    server.addConnector(connector)

    val ks = KeyStore.getInstance("JKS")
    ks.load(new FileInputStream("tls/keystore.jks"), "changeit".toCharArray)
    val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm)
    kmf.init(ks, "changeit".toCharArray)

    val ts = KeyStore.getInstance("JKS")
    ts.load(new FileInputStream("tls/truststore.jks"), "changeit".toCharArray)
    val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm)
    tmf.init(ts)

    val ctx = SSLContext.getInstance("TLS")
    ctx.init(kmf.getKeyManagers, tmf.getTrustManagers, null)

    val client = HttpClient.newBuilder().sslContext(ctx).build()

    server.setHandler(new Handler.Abstract {
      override def handle(request: Request, response: Response, callback: Callback): Boolean = {
        request.getHttpURI.getPath match {
          case "/external" =>
            println("External request - making internal call")
            val req = HttpRequest.newBuilder().uri(URI.create("https://localhost:8443/internal")).GET().build()
            val resp = client.send(req, HttpResponse.BodyHandlers.ofString())
            response.setStatus(200)
            response.write(true, java.nio.ByteBuffer.wrap(s"Success: ${resp.body()}".getBytes), callback)
          case "/internal" =>
            response.setStatus(200)
            response.write(true, java.nio.ByteBuffer.wrap("OK".getBytes), callback)
          case _ =>
            response.setStatus(404)
            callback.succeeded()
        }
        true
      }
    })

    server.start()
    println("Server started on port 8443")
    server.join()
  }
}

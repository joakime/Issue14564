name := "jetty-bug-reproduction"
version := "1.0"
scalaVersion := "2.13.12"

resolvers := Seq(
  "Maven Central" at "https://repo1.maven.org/maven2/"
)

libraryDependencies ++= Seq(
  "org.eclipse.jetty" % "jetty-server" % "12.1.5",
  "org.eclipse.jetty" % "jetty-alpn-server" % "12.1.5",
  "org.eclipse.jetty" % "jetty-alpn-java-server" % "12.1.5",
  "org.eclipse.jetty.http2" % "jetty-http2-server" % "12.1.5",
  "org.eclipse.jetty.http2" % "jetty-http2-common" % "12.1.5",
  "ch.qos.logback" % "logback-classic" % "1.5.26"
)

assembly / assemblyMergeStrategy := {
  case PathList("META-INF", "services", xs @ _*) => MergeStrategy.concat
  case PathList("META-INF", xs @ _*) => MergeStrategy.discard
  case "module-info.class" => MergeStrategy.discard
  case x => MergeStrategy.first
}
